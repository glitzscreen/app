# Glitz Screen (Kotlin / Jetpack Compose)

Native Android app (package `com.glitz.screen`) for your site's public `GET /api/...` endpoints.
No WebView.

1. Open this folder in Android Studio (the folder that contains `settings.gradle.kts`).
2. In `app/build.gradle.kts` set `val baseUrl = "https://YOUR-DOMAIN.com/"` (must end with `/`).
3. Gradle JDK must be 17 or 21. Sync, then Run.

## Endpoints used (all GET)
`/api/videos`, `/api/categories`, `/api/video`, `/api/comments`, `/api/search`,
`/api/player-settings`, `/api/facebook-direct`, `/api/facebook-quality-options`

## Player (same features and colours as the website)
Centre prev / play / next, +-skip seconds, seek bar with buffered part, time, speed (0.5x-2x),
quality menu, volume + sound boost (fullscreen), screen mode (fullscreen), picture-in-picture (fullscreen),
fullscreen, double-tap sides to seek, swipe left = brightness, swipe right = volume,
"Resumed from" toast, "Autoplay next video" option. Settings come from /api/player-settings.
