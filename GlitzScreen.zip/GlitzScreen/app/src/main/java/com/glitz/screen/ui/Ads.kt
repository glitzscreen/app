package com.glitz.screen.ui

import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.glitz.screen.data.AdTracker
import com.glitz.screen.data.PlayerSettings
import kotlinx.coroutines.delay

/** Runs one ad break exactly once: its end (complete, skip) is reported and handed back to the player. */
private class AdRun(private val kind: String, private val onDone: () -> Unit) {
    private var finished = false
    fun finish(event: String) {
        if (finished) return
        finished = true
        AdTracker.send(event, kind)
        onDone()
    }
}

/**
 * Full-screen ad break shown over the video, configured by the website's player settings:
 * image, video, HTML or a plain "Sponsored" slate; skip button after adSkipAfterSeconds;
 * tapping the ad opens adClickUrl.
 */
@Composable
fun AdBreak(kind: String, s: PlayerSettings, lengthSeconds: Int, onDone: () -> Unit) {
    val context = LocalContext.current
    val run = remember(kind) { AdRun(kind, onDone) }
    var elapsed by remember { mutableIntStateOf(0) }
    val length = lengthSeconds.coerceAtLeast(1)
    val canSkip = elapsed >= s.adSkipAfterSeconds
    val fit = when (s.adFitMode) {
        "fill" -> ContentScale.Crop
        "stretch" -> ContentScale.FillBounds
        else -> ContentScale.Fit
    }
    val resize = when (s.adFitMode) {
        "fill" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        "stretch" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    LaunchedEffect(kind) {
        AdTracker.send("impression", kind)
        while (elapsed < length) {
            delay(1000)
            elapsed++
        }
        run.finish("complete")
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .clickable {
                // always consume the tap (so it never reaches the paused video underneath);
                // open the advertiser's page only when one is set
                if (s.adClickUrl.isBlank()) return@clickable
                AdTracker.send("click", kind)
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(s.adClickUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            },
    ) {
        when (s.adCreativeType) {
            "image" -> AsyncImage(
                model = s.adCreativeUrl, contentDescription = s.adHeadline,
                contentScale = fit, modifier = Modifier.fillMaxSize(),
            )
            "video" -> AdVideo(s.adCreativeUrl, resize) { run.finish("complete") }
            "html" -> AdHtml(s.adCreativeHtml)
            else -> Box(Modifier.fillMaxSize().background(GlitzBg))
        }

        // "Sponsored" label
        Text(
            s.adHeadline.ifBlank { "Sponsored" }, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                .clip(RoundedCornerShape(4.dp)).background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 8.dp, vertical = 3.dp),
        )

        // subtext + countdown
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            if (s.adSubtext.isNotBlank()) Text(s.adSubtext, color = Color.White, fontSize = 12.sp)
            Text("Ad • ${(length - elapsed).coerceAtLeast(0)}s", color = GlitzMuted, fontSize = 11.sp)
        }

        // skip button (after the configured number of seconds)
        if (canSkip) {
            Text(
                "Skip ad ›", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    .clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = 0.7f))
                    .clickable { run.finish("skip") }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        } else {
            Text(
                "Skip in ${s.adSkipAfterSeconds - elapsed}s", color = GlitzMuted, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    .clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = 0.7f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun AdVideo(url: String, resize: Int, onEnded: () -> Unit) {
    val context = LocalContext.current
    val player = remember(url) { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) onEnded()
            }
        }
        player.addListener(listener)
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.playWhenReady = true
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = false
                resizeMode = resize
            }
        },
        update = { it.resizeMode = resize },
        modifier = Modifier.fillMaxSize(),
    )
}

@Composable
private fun AdHtml(html: String) {
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                // clicks inside the HTML ad open the system browser, not the app's WebView
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url ?: return true
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        return true
                    }
                }
                loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}
