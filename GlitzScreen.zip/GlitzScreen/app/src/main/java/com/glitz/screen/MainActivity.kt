package com.glitz.screen

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import com.glitz.screen.data.AppUpdateChecker
import com.glitz.screen.data.AuthStore
import com.glitz.screen.data.LiveSync
import com.glitz.screen.ui.*

@Composable
private fun glitzNavColors() = NavigationBarItemDefaults.colors(
        selectedIconColor = GlitzPrimary, selectedTextColor = GlitzPrimary,
        selectedIndicatorColor = GlitzPrimary.copy(alpha = 0.16f),
        unselectedIconColor = GlitzMuted, unselectedTextColor = GlitzMuted,
    )

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

class MainActivity : ComponentActivity() {
    override fun onStart() {
        super.onStart()
        LiveSync.start()
        AppUpdateChecker.refresh()
        AuthStore.refresh()
    }

    override fun onStop() {
        LiveSync.stop()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAuthIntent(intent)
    }

    /** Google sign-in finished in the browser: keep the session the website sent back. */
    private fun handleAuthIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.path?.startsWith("/app-auth") != true) return
        val session = uri.fragment?.split("&")
            ?.map { it.split("=", limit = 2) }
            ?.firstOrNull { it[0] == "session" }
            ?.getOrNull(1)
            ?: return
        AuthStore.save(session)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AuthStore.init(this)
        handleAuthIntent(intent)
        setContent {
            GlitzTheme {
                val ctx = LocalContext.current
                // Like the website: no splash when the system animations are turned off.
                val reduceMotion = remember {
                    Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
                }
                var splashDone by rememberSaveable { mutableStateOf(reduceMotion) }
                val splashMs = remember { SplashGate.nextDurationMs() }
                // The home screen fades up and slides 8dp, like the website's fbfIn animation.
                val appEnter by animateFloatAsState(
                    targetValue = if (splashDone) 1f else 0f,
                    animationSpec = tween(350),
                    label = "appEnter",
                )

                val nav = rememberNavController()
                val route = nav.currentBackStackEntryAsState().value?.destination?.route
                val showBar = route == "home" || route == "search" || route == "profile"

                Box(Modifier.fillMaxSize()) {
                    Scaffold(
                        containerColor = MaterialTheme.colorScheme.background,
                        bottomBar = {
                            if (showBar) NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                                NavigationBarItem(
                                    selected = route == "home", onClick = { nav.goTab("home") },
                                    icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Home") }, colors = glitzNavColors(),
                                )
                                NavigationBarItem(
                                    selected = route == "search", onClick = { nav.goTab("search") },
                                    icon = { Icon(Icons.Filled.Search, null) }, label = { Text("Search") }, colors = glitzNavColors(),
                                )
                                NavigationBarItem(
                                    selected = route == "profile", onClick = { nav.goTab("profile") },
                                    icon = { Icon(Icons.Filled.Person, null) }, label = { Text("Profile") }, colors = glitzNavColors(),
                                )
                            }
                        },
                    ) { pad ->
                        NavHost(
                            nav,
                            startDestination = "home",
                            modifier = Modifier
                                .padding(pad)
                                .graphicsLayer {
                                    alpha = appEnter
                                    translationY = (1f - appEnter) * 8.dp.toPx()
                                },
                        ) {
                            composable("home") {
                                HomeScreen(
                                    vm = viewModel<HomeViewModel>(),
                                    onSearch = { nav.goTab("search") },
                                    onOpen = { id -> nav.navigate("video/$id") },
                                )
                            }
                            composable("search") {
                                SearchScreen(
                                    vm = viewModel<SearchViewModel>(),
                                    onBack = { nav.goTab("home") },
                                    onOpen = { id -> nav.navigate("video/$id") },
                                )
                            }
                            composable("profile") {
                                ProfileScreen(onOpen = { id -> nav.navigate("video/$id") })
                            }
                            composable("video/{id}") { entry ->
                                val id = entry.arguments?.getString("id") ?: return@composable
                                val vm: DetailViewModel = viewModel(key = id, factory = object : ViewModelProvider.Factory {
                                    @Suppress("UNCHECKED_CAST")
                                    override fun <T : ViewModel> create(modelClass: Class<T>): T = DetailViewModel(id) as T
                                })
                                val hasPrev = nav.previousBackStackEntry?.destination?.route == "video/{id}"
                                WatchScreen(
                                    vm = vm,
                                    hasPrev = hasPrev,
                                    onBack = { nav.popBackStack() },
                                    onOpen = { next -> nav.navigate("video/$next") },
                                )
                            }
                        }
                    }

                    // App update: forced updates cover everything; optional ones can be postponed.
                    val update by AppUpdateChecker.pending.collectAsState()
                    val info = update
                    if (splashDone && info != null) {
                        val forced = AppUpdateChecker.isForced(info)
                        if (forced || !AppUpdateChecker.wasSkipped(ctx, info)) {
                            UpdateScreen(info = info, forced = forced, onLater = { AppUpdateChecker.skip(ctx, info) })
                        }
                    }

                    // Splash sits on top of everything until it fades out.
                    if (!splashDone) {
                        GlitzSplash(durationMs = splashMs, onFinished = { splashDone = true })
                    }
                }
            }
        }
    }
}
