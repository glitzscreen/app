package com.glitz.screen.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.glitz.screen.BuildConfig
import com.glitz.screen.data.Video

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun compact(n: Int?): String {
    val v = n ?: 0
    return when {
        v >= 1_000_000 -> "%.1fM".format(v / 1_000_000.0)
        v >= 1_000 -> "%.1fK".format(v / 1_000.0)
        else -> v.toString()
    }
}

fun setFullscreen(activity: Activity, on: Boolean, autoRotate: Boolean = true) {
    activity.requestedOrientation =
        if (on && autoRotate) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
    if (on) {
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    } else {
        controller.show(WindowInsetsCompat.Type.systemBars())
    }
}

fun shareVideo(context: Context, v: Video) {
    // The site redirects /watch?id=... to the pretty /watch/<title>-<id> URL.
    val link = BuildConfig.BASE_URL + "watch?id=" + v.shortId
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "${v.fileName ?: ""}\n$link")
    }
    context.startActivity(Intent.createChooser(intent, null))
}
