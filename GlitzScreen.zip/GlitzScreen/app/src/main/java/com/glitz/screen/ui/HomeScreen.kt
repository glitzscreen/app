package com.glitz.screen.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import coil.compose.AsyncImage
import com.glitz.screen.data.Api
import com.glitz.screen.data.ContinueItem
import com.glitz.screen.data.WatchProgress
import com.glitz.screen.data.formatDuration
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val sorts = listOf(
    "latest" to "Latest", "views" to "Most viewed",
    "liked" to "Most liked", "top_rated" to "Top rated",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: HomeViewModel, onSearch: () -> Unit, onOpen: (String) -> Unit) {
    val s by vm.state.collectAsState()
    var sortMenu by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val continueItems = remember(s.videos) { WatchProgress.continueWatching(ctx) }

    Column(Modifier.fillMaxSize()) {
        // ---- website-style header: animated reel logo + "Glitz Screen" wordmark ----
        Row(
            Modifier.fillMaxWidth()
                .background(GlitzBg.copy(alpha = 0.92f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlitzReel(30.dp)
            Spacer(Modifier.width(8.dp))
            GlitzWordmark()
            Spacer(Modifier.weight(1f))
            Box {
                IconButton(onClick = { sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Sort") }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    sorts.forEach { (key, label) ->
                        DropdownMenuItem(
                            text = { Text(label, fontWeight = if (key == s.sort) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { vm.setSort(key); sortMenu = false },
                        )
                    }
                }
            }
            IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, "Search") }
        }

        // ---- category chips ----
        val chipColors = FilterChipDefaults.filterChipColors(
            containerColor = GlitzSurface2, labelColor = Color.White,
            selectedContainerColor = GlitzPrimary, selectedLabelColor = GlitzInk,
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                FilterChip(
                    selected = s.selectedCategory == null, onClick = { vm.setCategory(null) },
                    label = { Text("All", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    colors = chipColors, border = null,
                )
            }
            items(s.categories) { c ->
                FilterChip(
                    selected = s.selectedCategory == c.slug, onClick = { vm.setCategory(c.slug) },
                    label = { Text(c.name ?: "", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    colors = chipColors, border = null,
                )
            }
        }

        // ---- feed ----
        when {
            s.loading -> LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) { items(3) { SkeletonCard() } }
            s.error != null -> Column(
                Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally,
            ) {
                Text(s.error ?: "", color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
                Button(onClick = vm::load) { Text("Retry") }
            }
            s.videos.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No videos found") }
            else -> LazyColumn(
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (continueItems.isNotEmpty()) item { ContinueRow(continueItems, onOpen) }
                items(s.videos, key = { it.shortId }) { v -> VideoCard(v) { onOpen(v.shortId) } }
            }
        }
    }
}

@Composable
private fun ContinueRow(list: List<ContinueItem>, onOpen: (String) -> Unit) {
    Column(Modifier.padding(top = 4.dp)) {
        Text(
            "CONTINUE WATCHING", color = GlitzPrimary, fontWeight = FontWeight.Bold,
            fontSize = 13.sp, letterSpacing = 1.5.sp,
            modifier = Modifier.padding(start = 12.dp, bottom = 8.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.shortId }) { entry ->
                Column(
                    Modifier.width(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(GlitzCardBrush)
                        .border(1.dp, GlitzBorder, RoundedCornerShape(12.dp))
                        .clickable { onOpen(entry.shortId) },
                ) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(GlitzSurface2)) {
                        AsyncImage(
                            model = entry.thumb, contentDescription = entry.title,
                            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
                        )
                        // progress along the bottom of the thumbnail
                        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(GlitzBorder)) {
                            Box(Modifier.fillMaxWidth(entry.progress).fillMaxHeight().background(GlitzBrand))
                        }
                    }
                    Column(Modifier.padding(10.dp)) {
                        Text(
                            entry.title.ifBlank { "Video" }, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "${formatDuration(((entry.durationMs - entry.positionMs) / 1000).toInt())} left",
                            color = GlitzMuted, fontSize = 11.sp,
                        )
                    }
                }
            }
        }
    }
}
