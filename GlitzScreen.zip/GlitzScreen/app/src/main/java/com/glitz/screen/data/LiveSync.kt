package com.glitz.screen.data

import com.glitz.screen.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live content sync: while the app is open it asks the website for its content revision
 * (GET api/content-version, bumped by every admin change). When the revision changes,
 * [changes] emits and the screens reload their data.
 *
 * The website caches public API responses for a short time, so after a change the app adds
 * ?_rev=<revision> to its content requests. That gives every request a new URL, which skips the cache.
 */
object LiveSync {
    private const val POLL_MS = 15_000L

    private val http = OkHttpClient.Builder()
        .callTimeout(15, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    /** Last revision seen from the website (null until the first check succeeds). */
    /** The revision the website reported last (what the admin changes bump). */
    @Volatile
    private var serverRev: String? = null

    /** Revision sent with content requests; differs from [serverRev] only right after a forced refresh. */
    @Volatile
    var currentRev: String? = null
        private set

    private val _changes = MutableSharedFlow<String>(extraBufferCapacity = 8)

    /** Emits the new revision each time the website content changes. */
    val changes: SharedFlow<String> = _changes.asSharedFlow()

    /** Called when the app comes to the foreground. */
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                poll()
                delay(POLL_MS)
            }
        }
    }

    /** Called when the app goes to the background, so it does not poll in the background. */
    fun stop() {
        job?.cancel()
        job = null
    }

    private suspend fun poll() {
        val rev = withContext(Dispatchers.IO) { fetchRev() } ?: return
        val previous = serverRev
        if (rev == previous) return
        serverRev = rev
        currentRev = rev
        // The first value only sets the baseline; later changes notify the screens.
        if (previous != null) _changes.tryEmit(rev)
    }

    private fun fetchRev(): String? = try {
        val request = Request.Builder()
            .url(BuildConfig.BASE_URL + "api/content-version")
            .cacheControl(CacheControl.FORCE_NETWORK)
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) null
            else JSONObject(response.body?.string() ?: "").optString("rev").ifBlank { null }
        }
    } catch (e: Exception) {
        null
    }

    /** Makes the screens reload with fresh data (after sign-in/out or a language change). */
    fun forceRefresh() {
        val base = serverRev ?: return
        val next = "$base.${System.nanoTime()}"
        currentRev = next
        _changes.tryEmit(next)
    }

    /** Adds ?_rev=<revision> to content GET requests. Playback links are left alone. */
    val cacheBustInterceptor = Interceptor { chain ->
        val request = chain.request()
        val rev = currentRev
        val path = request.url.encodedPath
        val skip = rev == null || !path.contains("/api/") ||
            path.contains("facebook") || path.contains("content-version") || path.contains("app-update")
        if (skip) {
            chain.proceed(request)
        } else {
            val url = request.url.newBuilder().setQueryParameter("_rev", rev).build()
            chain.proceed(request.newBuilder().url(url).build())
        }
    }
}
