package com.glitz.screen.data

import com.google.gson.annotations.SerializedName

// GET /api/videos  ->  { videos: [...] }
data class VideosResponse(val videos: List<Video> = emptyList())

data class Video(
    @SerializedName("short_id") val shortId: String,
    @SerializedName("file_name") val fileName: String?,
    val description: String?,
    @SerializedName("thumbnail_url") val thumbnailUrl: String?,
    @SerializedName("duration_seconds") val durationSeconds: Int?,
    @SerializedName("release_year") val releaseYear: Int?,
    val views: Int?,
    val likes: Int?,
    val dislikes: Int?,
    @SerializedName("avg_rating") val avgRating: Double?,
    @SerializedName("rating_count") val ratingCount: Int?,
    @SerializedName("category_name") val categoryName: String?,
    @SerializedName("category_slug") val categorySlug: String?,
    @SerializedName("year_slug") val yearSlug: String?,
    @SerializedName("coin_cost") val coinCost: Int?,
)

// GET /api/video?id=  ->  { video: {...} }
data class VideoResponse(val video: Video)

// GET /api/categories  ->  { categories: [...], years: [...] }
data class CategoriesResponse(
    val categories: List<Category> = emptyList(),
    val years: List<Category> = emptyList(),
)
data class Category(val id: Int?, val name: String?, val slug: String?)

// GET /api/comments?id=  ->  { comments: [...] }
data class CommentsResponse(val comments: List<Comment> = emptyList())
data class Comment(
    val id: Int,
    val body: String,
    @SerializedName("created_at") val createdAt: String?,
    val username: String?,
)

// GET /api/search?q=  ->  { videos: [...lean], series: [...] }
data class SearchResponse(
    val videos: List<SearchVideo> = emptyList(),
    val series: List<SearchSeries> = emptyList(),
)
data class SearchVideo(
    val shortId: String,
    val title: String?,
    val thumbnailUrl: String?,
    val duration: String?,
    val views: Int?,
    val locked: Boolean?,
)
data class SearchSeries(
    val slug: String,
    val title: String?,
    val thumbnailUrl: String?,
    val seasonCount: Int?,
    val episodeCount: Int?,
)

// GET /api/facebook-direct?shortId=&quality=auto  ->  playable URL
data class DirectSource(
    val src: String,
    val quality: String?,
    val expiresAt: Long?,
    val refreshInMs: Long?,
)

// GET /api/facebook-quality-options?shortId=  ->  { options: [{id, label}] }
data class QualityOption(val id: String, val label: String)
data class QualityOptionsResponse(val options: List<QualityOption> = emptyList())

// GET /api/player-settings  ->  { settings: {...} }  (same settings the website player uses)
data class PlayerSettingsResponse(val settings: PlayerSettings = PlayerSettings())
data class PlayerSettings(
    val themeColor: String = "#b5651d",
    val useSiteThemeColor: Boolean = true,
    val skipSeconds: Int = 10,
    val autoplay: Boolean = false,
    val allowPip: Boolean = true,
    val autoRotateFullscreen: Boolean = true,
    val videoFitMode: String = "none", // "none" = original resolution, "fill" = stretch
    val playbackSpeedControl: Boolean = true,
    val rememberPosition: Boolean = true,
    val autoNextDefault: Boolean = false,
    val allowQualityControl: Boolean = true,
    val defaultQuality: String = "auto",
    val gestureSensitivity: Int = 3,
    // ---- ads (website ad breaks) ----
    val adBreaksEnabled: Boolean = false,
    val prerollLengthSeconds: Int = 10,
    val midrollLengthSeconds: Int = 8,
    val midrollTriggerPercent: Int = 50,
    val adSkipAfterSeconds: Int = 10,
    val adHeadline: String = "Sponsored",
    val adSubtext: String = "Your video resumes automatically",
    val adCreativeType: String = "none", // none | image | video | html
    val adCreativeUrl: String = "",
    val adCreativeHtml: String = "",
    val adClickUrl: String = "",
    val adFitMode: String = "fit",       // fit | fill | stretch
    val adPrerollFrequency: String = "every_view", // every_view | once_session
    val adRewindEnabled: Boolean = false,
    val adRewindSeconds: Int = 10,
)
