package com.glitz.screen.data

import com.glitz.screen.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Sends ad stats to the website (the same beacon the website uses): impression, click, skip, complete. */
object AdTracker {
    private val http = OkHttpClient.Builder()
        .callTimeout(10, TimeUnit.SECONDS)
        .addInterceptor(AuthStore.interceptor)
        .build()

    fun send(event: String, brk: String) {
        Thread {
            runCatching {
                val body = JSONObject().put("event", event).put("brk", brk)
                    .toString().toRequestBody("application/json".toMediaType())
                http.newCall(Request.Builder().url(BuildConfig.BASE_URL + "api/ad-event").post(body).build())
                    .execute().close()
            }
        }.start()
    }
}

/** Remembers which videos already had a pre-roll this session (website: ad_preroll_frequency = once_session). */
object AdSession {
    private val seen = HashSet<String>()
    fun shown(id: String): Boolean = id in seen
    fun mark(id: String) { seen.add(id) }
}
