package com.glitz.screen.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.glitz.screen.data.Api
import com.glitz.screen.data.Video
import com.glitz.screen.data.formatDuration

/** Animated film-reel logo, same geometry as the website's .logo .mark.reel SVG. */
@Composable
fun GlitzReel(dim: Dp = 32.dp, spinMs: Int = 3600, orbitMs: Int = 11000) {
    val t = rememberInfiniteTransition(label = "reel")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(spinMs, easing = LinearEasing)), label = "spin",
    )
    val orbit by t.animateFloat(
        initialValue = 0f, targetValue = -360f,
        animationSpec = infiniteRepeatable(tween(orbitMs, easing = LinearEasing)), label = "orbit",
    )
    Canvas(Modifier.size(dim)) {
        val u = size.minDimension / 64f
        val c = Offset(32f * u, 32f * u)
        val dark = Color(0xF2020510)
        drawCircle(GlitzPrimary.copy(alpha = 0.18f), radius = 31f * u, center = c)
        rotate(orbit, pivot = c) {
            drawCircle(
                GlitzSecondary, radius = 30.2f * u, center = c,
                style = Stroke(width = 1.3f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f * u, 4.4f * u))),
            )
        }
        rotate(spin, pivot = c) {
            drawCircle(Color(0xD1060A18), 26f * u, c)
            drawCircle(GlitzPrimary, 26f * u, c, style = Stroke(width = 3f * u))
            listOf(
                47f to 32f, 39.5f to 45f, 24.5f to 45f,
                17f to 32f, 24.5f to 19f, 39.5f to 19f,
            ).forEach { (x, y) ->
                val hc = Offset(x * u, y * u)
                drawCircle(dark, 6.4f * u, hc)
                drawCircle(GlitzSecondary, 6.4f * u, hc, style = Stroke(width = 1.3f * u))
            }
            drawCircle(GlitzPrimary, 5.2f * u, c)
            drawCircle(dark, 1.8f * u, c)
        }
    }
}

/** "Glitz" bold + "Screen" muted, same split as the website's brand text. */
@Composable
fun GlitzWordmark(modifier: Modifier = Modifier) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold)) { append("Glitz") }
            append(" ")
            withStyle(SpanStyle(color = GlitzMuted, fontWeight = FontWeight.SemiBold)) { append("Screen") }
        },
        fontSize = 20.sp,
        modifier = modifier,
    )
}

/** HUD-style corner brackets, drawn over the card when it is pressed (website .card::before/::after). */
fun Modifier.hudCorners(color: Color, alpha: Float): Modifier = this.drawWithContent {
    drawContent()
    if (alpha <= 0f) return@drawWithContent
    val len = 14.dp.toPx()
    val w = 2.dp.toPx()
    val inset = 6.dp.toPx()
    val c = color.copy(alpha = alpha)
    drawLine(c, Offset(inset, inset), Offset(inset + len, inset), w)
    drawLine(c, Offset(inset, inset), Offset(inset, inset + len), w)
    drawLine(c, Offset(size.width - inset, size.height - inset), Offset(size.width - inset - len, size.height - inset), w)
    drawLine(c, Offset(size.width - inset, size.height - inset), Offset(size.width - inset, size.height - inset - len), w)
}

@Composable
fun DurationBadge(text: String, modifier: Modifier = Modifier) {
    if (text.isBlank()) return
    Text(
        text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
        modifier = modifier.padding(6.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xD9050812))
            .border(1.dp, GlitzBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp),
    )
}

@Composable
fun Avatar(label: String?, size: Int = 36) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(GlitzBrand),
        contentAlignment = Alignment.Center,
    ) {
        Text((label?.firstOrNull() ?: 'G').uppercase(), color = GlitzInk, fontWeight = FontWeight.Bold)
    }
}

/**
 * Website-style video card: gradient surface, thin border that lights up cyan when pressed,
 * 16:9 thumbnail with a bottom scrim and scanlines, HUD corner brackets, fade-and-rise entrance.
 */
@Composable
fun VideoCard(v: Video, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed) 0.97f else 1f, label = "press")
    val edge by animateColorAsState(if (pressed) GlitzPrimary else GlitzBorder, label = "edge")
    val brackets by animateFloatAsState(if (pressed) 1f else 0f, label = "brackets")
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(450)) }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .graphicsLayer {
                alpha = enter.value
                translationY = (1f - enter.value) * 24.dp.toPx()
                scaleX = pressScale
                scaleY = pressScale
            }
            .clip(RoundedCornerShape(14.dp))
            .background(GlitzCardBrush)
            .border(1.dp, edge, RoundedCornerShape(14.dp))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .hudCorners(GlitzPrimary, brackets),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(GlitzSurface2)) {
            AsyncImage(
                model = Api.absolute(v.thumbnailUrl), contentDescription = v.fileName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            // bottom scrim + subtle scanlines, like .thumb-wrap::after on the website
            Box(
                Modifier.matchParentSize().drawWithContent {
                    drawContent()
                    var y = 0f
                    while (y < size.height) {
                        drawLine(Color.White.copy(alpha = 0.03f), Offset(0f, y), Offset(size.width, y), 1f)
                        y += 3.dp.toPx()
                    }
                }.background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0xBF05080F))),
            )
            DurationBadge(formatDuration(v.durationSeconds), Modifier.align(Alignment.BottomEnd))
            if ((v.coinCost ?: 0) > 0) {
                Text(
                    "🔒 ${v.coinCost}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xB3050812))
                        .border(1.dp, GlitzBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(v.categoryName ?: v.fileName)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    v.fileName ?: "", fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    listOfNotNull(
                        v.categoryName, "${compact(v.views)} views", v.releaseYear?.toString(),
                    ).joinToString(" • "),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
fun SkeletonCard() {
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(
        initialValue = 0.05f, targetValue = 0.16f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "alpha",
    )
    val c = GlitzPrimary.copy(alpha = a)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(14.dp)).background(GlitzCardBrush)
            .border(1.dp, GlitzBorder, RoundedCornerShape(14.dp)),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(c))
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(c))
            Spacer(Modifier.width(12.dp))
            Column {
                Box(Modifier.fillMaxWidth(0.85f).height(14.dp).clip(RoundedCornerShape(4.dp)).background(c))
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth(0.5f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(c))
            }
        }
    }
}
