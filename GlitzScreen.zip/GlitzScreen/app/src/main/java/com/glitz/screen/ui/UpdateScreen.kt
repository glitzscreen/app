package com.glitz.screen.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glitz.screen.data.AppUpdateChecker
import com.glitz.screen.data.AppUpdateInfo

/** Opens the store page (preferred) or the APK download link. */
private fun openUpdate(context: Context, info: AppUpdateInfo) {
    val url = info.storeUrl.ifBlank { info.apkUrl }
    if (url.isBlank()) return
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/**
 * Update screen. Optional updates can be postponed with "Later".
 * Forced updates cover the whole app: there is no "Later" and Back does nothing.
 */
@Composable
fun UpdateScreen(info: AppUpdateInfo, forced: Boolean, onLater: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    BackHandler(enabled = true) { if (!forced) onLater() }

    Box(
        Modifier.fillMaxSize()
            .background(GlitzBg.copy(alpha = 0.96f))
            .clickable(onClick = {}), // swallow taps so nothing underneath can be used
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(24.dp).fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GlitzCardBrush)
                .border(1.dp, GlitzPrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            GlitzReel(56.dp)
            Spacer(Modifier.height(14.dp))
            Text(
                if (forced) "UPDATE REQUIRED" else "UPDATE AVAILABLE",
                color = GlitzPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Version ${info.versionName.ifBlank { info.versionCode.toString() }}",
                fontWeight = FontWeight.Bold, fontSize = 20.sp,
            )
            if (info.notes.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(info.notes, color = GlitzMuted, fontSize = 14.sp)
            }
            if (forced) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "This version is no longer supported. Please update to continue.",
                    color = GlitzMuted, fontSize = 12.sp,
                )
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = { openUpdate(context, info) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = GlitzPrimary, contentColor = GlitzInk),
            ) { Text(if (forced) "Update now" else "Update", fontWeight = FontWeight.Bold) }
            if (!forced) {
                TextButton(onClick = onLater, modifier = Modifier.fillMaxWidth()) {
                    Text("Later", color = GlitzMuted)
                }
            }
        }
    }
}
