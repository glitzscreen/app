package com.glitz.screen.ui

import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.glitz.screen.data.PlayerSettings
import com.glitz.screen.data.AdSession
import com.glitz.screen.data.Analytics
import com.glitz.screen.data.ContinueItem
import com.glitz.screen.data.QualityOption
import com.glitz.screen.data.WatchProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.log10

// Same option lists as the website player
private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
private val BOOSTS = listOf(1f, 1.5f, 2f, 2.5f, 3f)

/** Set when auto-next moves on to the next video, so that video starts playing by itself. */
object AutoPlayFlag {
    private var pending = false
    fun set() { pending = true }
    fun consume(): Boolean { val p = pending; pending = false; return p }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@Composable
fun GlitzPlayer(
    url: String,
    shortId: String,
    poster: String?,
    settings: PlayerSettings,
    qualityOptions: List<QualityOption>,
    quality: String,
    fullscreen: Boolean,
    inPip: Boolean,
    hasPrev: Boolean,
    hasNext: Boolean,
    autoNext: Boolean,
    onQuality: (String) -> Unit,
    onError: () -> Unit,
    onFullscreen: (Boolean) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    title: String = "",
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val prefs = remember { context.getSharedPreferences("glitz_player", Context.MODE_PRIVATE) }
    val player = remember { ExoPlayer.Builder(context).build() }
    val accent = remember(settings.themeColor, settings.useSiteThemeColor) {
        if (settings.useSiteThemeColor) GlitzPrimary
        else runCatching { Color(android.graphics.Color.parseColor(settings.themeColor)) }.getOrDefault(GlitzPrimary)
    }
    val onErrorCb by rememberUpdatedState(onError)
    val skipMs = settings.skipSeconds * 1000L
    val sensFactor = when (settings.gestureSensitivity) { 1 -> 1.6f; 2 -> 1.25f; 4 -> 0.75f; 5 -> 0.55f; else -> 1f }

    // ---- state ----
    var isPlaying by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var ended by remember { mutableStateOf(false) }
    var firstFrame by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var controlsVisible by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) } // bumped on every interaction to restart the 3s auto-hide
    var speedIdx by remember { mutableIntStateOf(SPEEDS.indexOf(prefs.getFloat("speed", 1f)).takeIf { it >= 0 } ?: 2) }
    var boostIdx by remember { mutableIntStateOf(BOOSTS.indexOf(prefs.getFloat("boost", 1f)).takeIf { it >= 0 } ?: 0) }
    var fitFill by remember { mutableStateOf(prefs.getBoolean("fit_fill", settings.videoFitMode == "fill")) }
    var volume by remember { mutableFloatStateOf(1f) }
    var lastVolume by remember { mutableFloatStateOf(1f) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubPos by remember { mutableFloatStateOf(0f) }
    var flash by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var hud by remember { mutableStateOf<Pair<String, Float>?>(null) }
    var note by remember { mutableStateOf<String?>(null) }
    var resumeFrom by remember { mutableStateOf<Long?>(null) }
    var qualityMenu by remember { mutableStateOf(false) }
    var enhancer by remember { mutableStateOf<LoudnessEnhancer?>(null) }
    var boostFailed by remember { mutableStateOf(false) }
    // ads: "preroll" / "midroll" while an ad break is on screen, null otherwise
    var adBreak by remember { mutableStateOf<String?>(null) }
    var prerollDone by remember(shortId) {
        mutableStateOf(settings.adPrerollFrequency == "once_session" && AdSession.shown(shortId))
    }
    var midrollDone by remember(shortId) { mutableStateOf(false) }

    val effectiveFill = if (fullscreen) fitFill else settings.videoFitMode == "fill"
    val pipOk = settings.allowPip && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    val showControls = !inPip && adBreak == null && (controlsVisible || !isPlaying || ended || scrubbing)

    // ---- actions ----
    fun togglePlay() {
        if (ended) { player.seekTo(0); player.play() }
        else if (player.isPlaying) player.pause() else player.play()
        tick++
    }
    fun seekBy(ms: Long) {
        val d = if (player.duration == C.TIME_UNSET) Long.MAX_VALUE else player.duration
        player.seekTo((player.currentPosition + ms).coerceIn(0L, d))
        flash = (if (ms < 0) -1 else 1) to (if (ms < 0) "⏪ ${settings.skipSeconds}s" else "${settings.skipSeconds}s ⏩")
        tick++
    }
    fun applyBoost() {
        val g = BOOSTS[boostIdx]
        try {
            if (g <= 1f) { enhancer?.enabled = false }
            else {
                val e = enhancer ?: LoudnessEnhancer(player.audioSessionId).also { enhancer = it }
                e.setTargetGain((2000 * log10(g.toDouble())).toInt())
                e.enabled = true
            }
        } catch (_: Exception) { boostFailed = true }
    }
    fun adjustBrightness(d: Float) {
        val act = activity ?: return
        val lp = act.window.attributes
        val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
        val v = (cur + d).coerceIn(0.02f, 1f)
        lp.screenBrightness = v
        act.window.attributes = lp
        hud = "☀" to v
    }
    fun adjustVolume(d: Float) {
        val v = (player.volume + d).coerceIn(0f, 1f)
        player.volume = v
        volume = v
        hud = "🔊" to v
    }

    fun toggleMute() {
        val v = if (player.volume > 0f) { lastVolume = player.volume; 0f }
                else if (lastVolume > 0f) lastVolume else 1f
        player.volume = v
        volume = v
        tick++
    }
    fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity?.enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        }
    }
    // Remember where the viewer is, for the "Continue watching" row on the home screen
    fun saveProgress() {
        if (!settings.rememberPosition) return
        val d = player.duration
        if (d == C.TIME_UNSET || d <= 0) return
        WatchProgress.save(context, ContinueItem(shortId, title, poster, player.currentPosition, d))
        Analytics.syncHistory(shortId, player.currentPosition, d)
    }
    // Keyboard shortcuts (hardware keyboards / TV remotes): space, arrows, M, F, P
    fun handleKey(e: KeyEvent): Boolean {
        if (adBreak != null) return true
        if (!settings.keyboardShortcuts || e.type != KeyEventType.KeyDown) return false
        return when (e.key) {
            Key.Spacebar -> { togglePlay(); true }
            Key.DirectionLeft -> { seekBy(-skipMs); true }
            Key.DirectionRight -> { seekBy(skipMs); true }
            Key.DirectionUp -> { adjustVolume(0.05f); true }
            Key.DirectionDown -> { adjustVolume(-0.05f); true }
            Key.M -> { toggleMute(); true }
            Key.F -> { onFullscreen(!fullscreen); true }
            Key.P -> { if (pipOk) enterPip(); true }
            else -> false
        }
    }

    // ---- player wiring ----
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) {
                isPlaying = p
                if (!p) saveProgress()
                // an ad break is on screen: the video stays paused underneath it
                if (p && adBreak != null) { player.pause(); return }
                // pre-roll: the first time playback starts, the ad plays first
                if (p && settings.adBreaksEnabled && !prerollDone) { player.pause(); adBreak = "preroll" }
            }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                ended = state == Player.STATE_ENDED
                if (state == Player.STATE_ENDED) {
                    prefs.edit().remove("pos_$shortId").apply()
                    WatchProgress.markCompleted(context, shortId)
                }
            }
            override fun onRenderedFirstFrame() { firstFrame = true }
            override fun onPlayerError(error: PlaybackException) { onErrorCb() }
        }
        player.addListener(l)
        onDispose {
            saveProgress()
            player.removeListener(l)
            try { enhancer?.release() } catch (_: Exception) {}
            player.release()
        }
    }

    // Pause when the app really leaves the screen (PiP keeps the activity started, so it keeps playing)
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) { saveProgress(); player.pause() } }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }

    // The swipe gesture changes the window brightness: give it back to the system when the player closes
    DisposableEffect(Unit) {
        onDispose {
            activity?.let { act ->
                val lp = act.window.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                act.window.attributes = lp
            }
        }
    }
    // The saved sound boost is applied once audio exists (after the first frame)
    LaunchedEffect(firstFrame) { if (firstFrame && boostIdx > 0) applyBoost() }

    // (Re)load whenever the URL changes (first load, quality switch, expired-link refresh)
    LaunchedEffect(url) {
        val first = player.mediaItemCount == 0
        val resumePos = if (first) { if (settings.rememberPosition) prefs.getLong("pos_$shortId", 0L) else 0L }
                        else player.currentPosition
        val fromAutoNext = AutoPlayFlag.consume()
        val keepPlaying = if (first) settings.autoplay || fromAutoNext else player.playWhenReady
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.playbackParameters = PlaybackParameters(SPEEDS[speedIdx])
        if (resumePos > 5000) {
            player.seekTo(resumePos)
            if (first) resumeFrom = resumePos
        }
        player.playWhenReady = keepPlaying
    }

    // Progress polling + remember position (like the website's "Resumed from")
    LaunchedEffect(player) {
        var n = 0
        // analytics state: how much was watched, whether the view was counted, when to retry
        var watchedSec = 0.0
        var counted = false
        var nextTry = 5.0
        while (true) {
            position = player.currentPosition
            duration = if (player.duration == C.TIME_UNSET) 0L else player.duration
            buffered = player.bufferedPosition
            if (++n % 20 == 0 && settings.rememberPosition && player.isPlaying &&
                duration > 0 && position > 5000 && position < duration - 10_000
            ) prefs.edit().putLong("pos_$shortId", position).apply()
            // mid-roll: once the viewer reaches the configured percentage of the video
            if (settings.adBreaksEnabled && !midrollDone && adBreak == null && duration > 0 && player.isPlaying &&
                position >= duration * settings.midrollTriggerPercent / 100
            ) {
                midrollDone = true
                player.pause()
                adBreak = "midroll"
            }
            // analytics: the view counts once enough has been watched (retry every 5 s until the website accepts it);
            // a "watching now" heartbeat every minute
            if (player.isPlaying) watchedSec += 0.25
            if (!counted && watchedSec >= nextTry) {
                counted = withContext(Dispatchers.IO) { Analytics.countView(context, shortId, watchedSec.toInt()) }
                nextTry = watchedSec + 5
            }
            if (n % 240 == 1) withContext(Dispatchers.IO) { Analytics.heartbeat(context, shortId) }
            if (n % 40 == 0 && player.isPlaying) saveProgress()
            delay(250)
        }
    }

    // Auto-hide controls after 3s while playing
    LaunchedEffect(controlsVisible, isPlaying, tick, scrubbing, qualityMenu) {
        if (controlsVisible && isPlaying && !scrubbing && !qualityMenu) {
            delay(3000)
            controlsVisible = false
        }
    }
    LaunchedEffect(flash) { if (flash != null) { delay(600); flash = null } }
    LaunchedEffect(hud) { if (hud != null) { delay(900); hud = null } }
    LaunchedEffect(note) { if (note != null) { delay(1000); note = null } }
    LaunchedEffect(resumeFrom) { if (resumeFrom != null) { delay(6000); resumeFrom = null } }
    LaunchedEffect(ended, autoNext, hasNext) { if (ended && autoNext && hasNext) { delay(800); AutoPlayFlag.set(); onNext() } }

    // ================= UI =================
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(focus).focusable()
            .onPreviewKeyEvent { e -> handleKey(e) },
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    keepScreenOn = true
                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                }
            },
            update = {
                it.resizeMode = if (effectiveFill) AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else AspectRatioFrameLayout.RESIZE_MODE_FIT
            },
            modifier = Modifier.fillMaxSize(),
        )
        if (!firstFrame && !poster.isNullOrBlank()) {
            AsyncImage(poster, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }

        // Touch layer: tap = show/hide controls, double-tap sides = seek, centre = fullscreen,
        // vertical swipe left = brightness, right = volume (same as the website)
        if (!inPip) {
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(fullscreen, skipMs) {
                        detectTapGestures(
                            onTap = { controlsVisible = !controlsVisible; tick++ },
                            onDoubleTap = { off ->
                                when {
                                    off.x < size.width / 3f -> seekBy(-skipMs)
                                    off.x > size.width * 2f / 3f -> seekBy(skipMs)
                                    else -> onFullscreen(!fullscreen)
                                }
                            },
                        )
                    }
                    .pointerInput(sensFactor) {
                        var left = true
                        detectVerticalDragGestures(
                            onDragStart = { off -> left = off.x < size.width / 2f },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                val d = (-dy / size.height) / sensFactor
                                if (left) adjustBrightness(d) else adjustVolume(d)
                            },
                        )
                    },
            )
        }

        // seek flash (⏪ 10s / 10s ⏩)
        flash?.let { (side, label) ->
            Text(
                label, color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(if (side < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 40.dp).clip(RoundedCornerShape(24.dp))
                    .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
        // brightness / volume HUD
        hud?.let { (icon, v) ->
            Text(
                "$icon ${(v * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp)
                    .clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            )
        }
        // generic note (screen mode / boost unsupported)
        note?.let {
            Text(
                it, color = Color.White, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp)
                    .clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            )
        }
        // scrub time bubble
        if (scrubbing && !inPip) {
            Text(
                fmt((scrubPos * duration).toLong()), color = Color.White, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 92.dp)
                    .clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
        // resume toast
        resumeFrom?.let { pos ->
            if (!inPip) Row(
                Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 84.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("▶ Resumed from ${fmt(pos)}", color = Color.White, fontSize = 12.sp)
                Text("↺ Start over", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { player.seekTo(0); resumeFrom = null })
                Text("✕", color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.clickable { resumeFrom = null })
            }
        }
        // buffering spinner
        if (buffering && !ended && !inPip) {
            if (settings.filmReelDecoration) {
                Box(Modifier.align(Alignment.Center)) { GlitzReel(dim = 56.dp, spinMs = 1600, orbitMs = 5000) }
            } else {
                CircularProgressIndicator(color = accent, modifier = Modifier.align(Alignment.Center).size(44.dp))
            }
        }

        // centre buttons: prev | play/pause | next
        AnimatedVisibility(
            visible = showControls && !buffering,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(), exit = fadeOut(),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                NavCircle(Icons.Filled.SkipPrevious, enabled = hasPrev) { tick++; onPrev() }
                Box(
                    Modifier.size(68.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f))
                        .clickable { togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (ended) Icons.Filled.Replay else if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "Play/Pause", tint = Color.White, modifier = Modifier.size(38.dp),
                    )
                }
                NavCircle(Icons.Filled.SkipNext, enabled = hasNext) { tick++; onNext() }
            }
        }

        // bottom controls bar
        AnimatedVisibility(
            visible = showControls,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(), exit = fadeOut(),
        ) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                    .padding(horizontal = 10.dp).padding(top = 16.dp, bottom = 4.dp),
            ) {
                val progress = if (scrubbing) scrubPos else if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
                val bufFrac = if (duration > 0) (buffered.toFloat() / duration).coerceIn(0f, 1f) else 0f
                SeekBar(
                    progress = progress, buffered = bufFrac, accent = accent,
                    onScrubStart = { scrubbing = true; scrubPos = it },
                    onScrub = { scrubPos = it },
                    onScrubEnd = { p -> player.seekTo((p * duration).toLong()); scrubbing = false; tick++ },
                    onTapSeek = { p -> player.seekTo((p * duration).toLong()); tick++ },
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CtlButton({ togglePlay() }) {
                        Icon(
                            if (ended) Icons.Filled.Replay else if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            "Play/Pause", tint = Color.White,
                        )
                    }
                    CtlButton({ seekBy(-skipMs) }) {
                        Icon(Icons.Filled.Replay, "Back", tint = Color.White, modifier = Modifier.size(22.dp))
                        Text("${settings.skipSeconds}", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    CtlButton({ seekBy(skipMs) }) {
                        Icon(Icons.Filled.Refresh, "Forward", tint = Color.White, modifier = Modifier.size(22.dp))
                        Text("${settings.skipSeconds}", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    if (fullscreen) CtlButton({ player.seekTo(0); tick++ }) {
                        Icon(Icons.Filled.RestartAlt, "Start over", tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                    Text(
                        "${fmt(if (scrubbing) (scrubPos * duration).toLong() else position)} / ${fmt(duration)}",
                        color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp),
                    )
                    Spacer(Modifier.weight(1f))

                    if (settings.playbackSpeedControl) {
                        CtlText("${SPEEDS[speedIdx].toString().removeSuffix(".0")}x") {
                            speedIdx = (speedIdx + 1) % SPEEDS.size
                            player.playbackParameters = PlaybackParameters(SPEEDS[speedIdx])
                            prefs.edit().putFloat("speed", SPEEDS[speedIdx]).apply()
                            tick++
                        }
                    }
                    if (fullscreen) {
                        CtlButton({ toggleMute() }) {
                            Icon(
                                if (volume == 0f) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                "Mute", tint = Color.White, modifier = Modifier.size(22.dp),
                            )
                        }
                        Slider(
                            value = volume,
                            onValueChange = { volume = it; player.volume = it; tick++ },
                            modifier = Modifier.width(90.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = accent, activeTrackColor = accent,
                                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
                            ),
                        )
                        CtlText(if (boostFailed) "N/A" else "${(BOOSTS[boostIdx] * 100).toInt()}%",
                            color = if (BOOSTS[boostIdx] > 1f) accent else Color.White) {
                            if (boostFailed) { note = "Sound boost isn't supported for this video"; return@CtlText }
                            boostIdx = (boostIdx + 1) % BOOSTS.size
                            applyBoost()
                            prefs.edit().putFloat("boost", BOOSTS[boostIdx]).apply()
                            tick++
                        }
                    }
                    if (pipOk) CtlButton({ enterPip() }) {
                        Icon(Icons.Filled.PictureInPictureAlt, "Picture in picture", tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                    if (settings.allowQualityControl && qualityOptions.isNotEmpty()) {
                        Box {
                            val label = if (quality == "auto") "Auto"
                                else qualityOptions.firstOrNull { it.id == quality }?.label ?: quality.uppercase()
                            CtlText(label) { qualityMenu = true; tick++ }
                            DropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                                val items = listOf(QualityOption("auto", "Auto")) + qualityOptions.filter { it.id != "auto" }
                                items.forEach { opt ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(opt.label, fontWeight = if (opt.id == quality) FontWeight.Bold else FontWeight.Normal,
                                                color = if (opt.id == quality) accent else MaterialTheme.colorScheme.onSurface)
                                        },
                                        onClick = { qualityMenu = false; if (opt.id != quality) onQuality(opt.id) },
                                    )
                                }
                            }
                        }
                    }
                    if (fullscreen) CtlButton({
                        fitFill = !fitFill
                        prefs.edit().putBoolean("fit_fill", fitFill).apply()
                        note = if (fitFill) "Stretch to fit" else "Original resolution"
                        tick++
                    }) { Icon(Icons.Filled.AspectRatio, "Screen mode", tint = if (fitFill) accent else Color.White, modifier = Modifier.size(22.dp)) }
                    CtlButton({ onFullscreen(!fullscreen) }) {
                        Icon(
                            if (fullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            "Fullscreen", tint = Color.White,
                        )
                    }
                }
            }
        }
        // ad break: covers the video and the controls until the ad ends
        adBreak?.let { kind ->
            AdBreak(
                kind = kind,
                s = settings,
                lengthSeconds = if (kind == "preroll") settings.prerollLengthSeconds else settings.midrollLengthSeconds,
                onDone = {
                    if (kind == "preroll") {
                        prerollDone = true
                        AdSession.mark(shortId)
                    }
                    adBreak = null
                    if (kind == "midroll" && settings.adRewindEnabled) {
                        player.seekTo((player.currentPosition - settings.adRewindSeconds * 1000L).coerceAtLeast(0L))
                    }
                    player.play()
                },
            )
        }
    }
}

@Composable
private fun NavCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape).background(Color.Black.copy(alpha = if (enabled) 0.55f else 0.25f))
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = Color.White.copy(alpha = if (enabled) 1f else 0.35f), modifier = Modifier.size(26.dp)) }
}

@Composable
private fun CtlButton(onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center, content = content,
    )
}

@Composable
private fun CtlText(label: String, color: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.heightIn(min = 36.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

/** Seek bar like the website's: grey track, lighter buffered part, accent-coloured progress. */
@Composable
private fun SeekBar(
    progress: Float,
    buffered: Float,
    accent: Color,
    onScrubStart: (Float) -> Unit,
    onScrub: (Float) -> Unit,
    onScrubEnd: (Float) -> Unit,
    onTapSeek: (Float) -> Unit,
) {
    Canvas(
        Modifier.fillMaxWidth().height(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { off -> onTapSeek((off.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                var last = 0f
                detectDragGestures(
                    onDragStart = { off -> last = (off.x / size.width).coerceIn(0f, 1f); onScrubStart(last) },
                    onDragEnd = { onScrubEnd(last) },
                    onDragCancel = { onScrubEnd(last) },
                    onDrag = { change, _ ->
                        change.consume()
                        last = (change.position.x / size.width).coerceIn(0f, 1f)
                        onScrub(last)
                    },
                )
            }
    ) {
        val h = 4.dp.toPx()
        val cy = size.height / 2
        val r = CornerRadius(h / 2)
        drawRoundRect(Color.White.copy(alpha = 0.22f), Offset(0f, cy - h / 2), Size(size.width, h), r)
        drawRoundRect(Color.White.copy(alpha = 0.4f), Offset(0f, cy - h / 2), Size(size.width * buffered, h), r)
        drawRoundRect(accent, Offset(0f, cy - h / 2), Size(size.width * progress, h), r)
        drawCircle(accent, 7.dp.toPx(), Offset(size.width * progress, cy))
    }
}
