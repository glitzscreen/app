package com.glitz.screen.data

import com.glitz.screen.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface ApiService {

    @GET("api/videos")
    suspend fun getVideos(
        @Query("q") q: String? = null,
        @Query("category") category: String? = null,
        @Query("year") year: String? = null,
        @Query("sort") sort: String = "latest", // latest | views | liked | top_rated
    ): VideosResponse

    @GET("api/video")
    suspend fun getVideo(@Query("id") id: String): VideoResponse

    @GET("api/categories")
    suspend fun getCategories(): CategoriesResponse

    @GET("api/comments")
    suspend fun getComments(@Query("id") id: String): CommentsResponse

    @GET("api/search")
    suspend fun search(@Query("q") q: String): SearchResponse

    @GET("api/facebook-direct")
    suspend fun getDirectSource(
        @Query("shortId") shortId: String,
        @Query("quality") quality: String = "auto",
        @Query("refresh") refresh: Int? = null, // pass 1 to force a fresh URL if playback fails
    ): DirectSource

    @GET("api/me")
    suspend fun getMe(): MeResponse

    @POST("api/logout")
    suspend fun logout()

    @POST("api/profile/lang-mode")
    suspend fun setLangMode(@Body body: LangModeBody): LangModeResponse

    @GET("api/app-update")
    suspend fun getAppUpdate(): AppUpdateInfo

    @GET("api/player-settings")
    suspend fun getPlayerSettings(): PlayerSettingsResponse

    @GET("api/facebook-quality-options")
    suspend fun getQualityOptions(@Query("shortId") shortId: String): QualityOptionsResponse
}

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(LiveSync.cacheBustInterceptor)
        .addInterceptor(AuthStore.interceptor)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC
            else HttpLoggingInterceptor.Level.NONE
        })
        .build()

    val service: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    /** Thumbnails may be relative paths; make them absolute. */
    fun absolute(url: String?): String? = when {
        url.isNullOrBlank() -> null
        url.startsWith("http") -> url
        else -> BuildConfig.BASE_URL.trimEnd('/') + "/" + url.trimStart('/')
    }
}

fun formatDuration(seconds: Int?): String {
    val s = seconds ?: return ""
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}
