package com.glitz.screen.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import com.glitz.screen.BuildConfig
import com.glitz.screen.data.AuthStore
import com.glitz.screen.data.MeUser
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import com.glitz.screen.data.ContinueItem
import com.glitz.screen.data.LocalProfile
import com.glitz.screen.data.WatchProgress

/** Profile tab: name, stats and this device's watch history. */
@Composable
fun ProfileScreen(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val signedIn by AuthStore.signedIn.collectAsState()
    val account by AuthStore.user.collectAsState()
    var history by remember { mutableStateOf(WatchProgress.all(ctx)) }
    var name by remember { mutableStateOf(LocalProfile.name(ctx)) }
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf(name) }
    var confirmClear by remember { mutableStateOf(false) }

    val finished = history.count { it.completed }
    val watchedMs = history.sumOf { it.positionMs }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        // ---- header: avatar, name, stats ----
        item {
            Column(
                Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Avatar(name, size = 72)
                Spacer(Modifier.height(12.dp))
                if (editing) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it.take(24) },
                        singleLine = true,
                        label = { Text("Your name") },
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { draft = name; editing = false }) { Text("Cancel", color = GlitzMuted) }
                        Button(
                            onClick = {
                                val n = draft.trim().ifBlank { "Guest" }
                                LocalProfile.setName(ctx, n)
                                name = n
                                editing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GlitzPrimary, contentColor = GlitzInk),
                        ) { Text("Save", fontWeight = FontWeight.Bold) }
                    }
                } else {
                    Text(name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TextButton(onClick = { draft = name; editing = true }) {
                        Text("Edit name", color = GlitzPrimary)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("${history.size}", "Videos", Modifier.weight(1f))
                    StatCard("$finished", "Finished", Modifier.weight(1f))
                    StatCard(formatWatchTime(watchedMs), "Watched", Modifier.weight(1f))
                }
            }
        }

        // ---- account: Google sign-in, language ----
        item { AccountCard(signedIn, account) }

        // ---- history header ----
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "WATCH HISTORY", color = GlitzPrimary, fontWeight = FontWeight.Bold,
                    fontSize = 13.sp, letterSpacing = 1.5.sp,
                )
                Spacer(Modifier.weight(1f))
                if (history.isNotEmpty()) {
                    TextButton(onClick = { confirmClear = true }) { Text("Clear", color = GlitzMuted) }
                }
            }
        }

        if (history.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("Videos you watch will appear here", color = GlitzMuted)
                }
            }
        }

        items(history, key = { it.shortId }) { entry ->
            HistoryRow(
                entry = entry,
                onOpen = { onOpen(entry.shortId) },
                onRemove = {
                    WatchProgress.remove(ctx, entry.shortId)
                    history = WatchProgress.all(ctx)
                },
            )
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear watch history?") },
            text = { Text("This removes your history and the continue-watching list from this device.") },
            confirmButton = {
                TextButton(onClick = {
                    WatchProgress.clear(ctx)
                    history = emptyList()
                    confirmClear = false
                }) { Text("Clear", color = GlitzPrimary, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(GlitzCardBrush)
            .border(1.dp, GlitzBorder, RoundedCornerShape(12.dp))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = GlitzPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = GlitzMuted, fontSize = 11.sp)
    }
}

@Composable
private fun HistoryRow(entry: ContinueItem, onOpen: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(GlitzCardBrush)
            .border(1.dp, GlitzBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.width(128.dp).aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp)).background(GlitzSurface2),
        ) {
            AsyncImage(
                model = entry.thumb, contentDescription = entry.title,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(GlitzBorder)) {
                Box(Modifier.fillMaxWidth(entry.progress).fillMaxHeight().background(GlitzBrand))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.title.ifBlank { "Video" }, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(4.dp))
            val status = if (entry.completed) "Finished" else "${(entry.progress * 100).toInt()}% watched"
            Text(
                "$status • ${timeAgo(entry.watchedAt)}", color = GlitzMuted, fontSize = 12.sp,
            )
        }
        IconButton(onClick = onRemove) {
            Icon(Icons.Filled.Close, "Remove from history", tint = GlitzMuted)
        }
    }
}

private fun timeAgo(at: Long): String {
    if (at <= 0L) return ""
    val mins = (System.currentTimeMillis() - at) / 60_000
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "${mins}m ago"
        mins < 1440 -> "${mins / 60}h ago"
        else -> "${mins / 1440}d ago"
    }
}

private fun formatWatchTime(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

private val LANGUAGES = listOf("tamil" to "தமிழ் · Tamil", "english" to "English")

@Composable
private fun AccountCard(signedIn: Boolean, user: MeUser?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(GlitzCardBrush)
            .border(1.dp, GlitzBorder, RoundedCornerShape(12.dp))
            .padding(14.dp),
    ) {
        if (!signedIn) {
            Text("Sign in to sync your account", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Sign in with Google to save your language choice to your account.",
                color = GlitzMuted, fontSize = 12.sp,
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { openInBrowser(ctx, BuildConfig.BASE_URL + "auth/google?return=/app-auth") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = GlitzPrimary, contentColor = GlitzInk),
            ) { Text("Continue with Google", fontWeight = FontWeight.Bold) }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(user?.username?.ifBlank { null } ?: "Signed in", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    user?.country?.takeIf { it.isNotBlank() }?.let {
                        Text("Country: $it", color = GlitzMuted, fontSize = 12.sp)
                    }
                }
                TextButton(onClick = { AuthStore.signOut() }) { Text("Sign out", color = GlitzMuted) }
            }
            if (user?.usernameConfirmed == 0) {
                TextButton(onClick = { openInBrowser(ctx, BuildConfig.BASE_URL + "welcome") }) {
                    Text("Choose your username", color = GlitzPrimary)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "LANGUAGE", color = GlitzPrimary, fontWeight = FontWeight.Bold,
                fontSize = 12.sp, letterSpacing = 1.5.sp,
            )
            Spacer(Modifier.height(8.dp))
            val current = user?.langPref ?: "tamil"
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LANGUAGES.forEach { (id, label) ->
                    FilterChip(
                        selected = current == id,
                        onClick = { if (current != id) scope.launch { AuthStore.setLanguage(id) } },
                        label = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = GlitzSurface2, labelColor = Color.White,
                            selectedContainerColor = GlitzPrimary, selectedLabelColor = GlitzInk,
                        ),
                        border = null,
                    )
                }
            }
        }
    }
}

private fun openInBrowser(ctx: android.content.Context, url: String) {
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
