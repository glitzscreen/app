package com.glitz.screen.ui

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.PictureInPictureModeChangedInfo
import androidx.core.util.Consumer
import com.glitz.screen.data.Api

@Composable
fun WatchScreen(vm: DetailViewModel, hasPrev: Boolean, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val s by vm.state.collectAsState()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("glitz_player", Context.MODE_PRIVATE) }
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    var descExpanded by rememberSaveable { mutableStateOf(false) }
    var inPip by remember { mutableStateOf(false) }
    var autoNext by remember(s.settings) {
        mutableStateOf(prefs.getBoolean("auto_next", s.settings.autoNextDefault))
    }
    val nextId = s.related.firstOrNull()?.shortId
    val accent = if (s.settings.useSiteThemeColor) GlitzPrimary
        else runCatching { Color(android.graphics.Color.parseColor(s.settings.themeColor)) }.getOrDefault(GlitzPrimary)

    fun setFs(on: Boolean) {
        fullscreen = on
        context.findActivity()?.let { setFullscreen(it, on, s.settings.autoRotateFullscreen) }
    }
    BackHandler(enabled = fullscreen) { setFs(false) }
    DisposableEffect(Unit) { onDispose { context.findActivity()?.let { setFullscreen(it, false) } } }

    // Track Picture-in-Picture so the page shows only the video while in the small window
    DisposableEffect(context) {
        val act = context.findActivity() as? ComponentActivity
        val listener = Consumer<PictureInPictureModeChangedInfo> { inPip = it.isInPictureInPictureMode }
        act?.addOnPictureInPictureModeChangedListener(listener)
        onDispose { act?.removeOnPictureInPictureModeChangedListener(listener) }
    }

    val bigPlayer = fullscreen || inPip

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(
            (if (bigPlayer) Modifier.weight(1f).fillMaxWidth()
            else Modifier.fillMaxWidth().aspectRatio(16f / 9f)).background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            val url = s.streamUrl
            when {
                url != null -> GlitzPlayer(
                    url = url,
                    shortId = vm.shortId,
                    poster = Api.absolute(s.video?.thumbnailUrl),
                    title = s.video?.fileName ?: "",
                    settings = s.settings,
                    qualityOptions = s.qualityOptions,
                    quality = s.quality,
                    fullscreen = fullscreen,
                    inPip = inPip,
                    hasPrev = hasPrev,
                    hasNext = nextId != null,
                    autoNext = autoNext,
                    onQuality = vm::setQuality,
                    onError = vm::refreshStream,
                    onFullscreen = { setFs(it) },
                    onPrev = onBack,
                    onNext = { nextId?.let(onOpen) },
                )
                s.loading -> CircularProgressIndicator(color = accent)
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(s.error ?: "", color = MaterialTheme.colorScheme.error)
                    Button(onClick = vm::load) { Text("Retry") }
                }
            }
            if (!bigPlayer) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.align(Alignment.TopStart).padding(4.dp)
                        .clip(CircleShape).background(Color.Black.copy(alpha = 0.4f)),
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            }
        }

        if (!bigPlayer) {
            val v = s.video
            LazyColumn(Modifier.fillMaxSize()) {
                // "Autoplay next video" row, directly under the player like the website
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            autoNext = !autoNext
                            prefs.edit().putBoolean("auto_next", autoNext).apply()
                        }.padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = autoNext,
                            onCheckedChange = {
                                autoNext = it
                                prefs.edit().putBoolean("auto_next", it).apply()
                            },
                            colors = CheckboxDefaults.colors(checkedColor = accent, checkmarkColor = GlitzInk),
                        )
                        Text("Autoplay next video", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                        Text(v?.fileName ?: "", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            listOfNotNull("${compact(v?.views)} views", v?.releaseYear?.toString(), v?.categoryName)
                                .joinToString(" • "),
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                        )
                    }
                }
                item {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Pill(Icons.Filled.ThumbUp, compact(v?.likes))
                        Pill(Icons.Filled.ThumbDown, compact(v?.dislikes))
                        v?.avgRating?.takeIf { it > 0 }?.let { Pill(Icons.Filled.Star, "%.1f".format(it)) }
                        Pill(Icons.Filled.Share, "Share") { v?.let { shareVideo(context, it) } }
                    }
                }
                if (!v?.description.isNullOrBlank()) {
                    item {
                        Column(
                            Modifier.padding(horizontal = 12.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(GlitzSurface2).clickable { descExpanded = !descExpanded }.padding(12.dp),
                        ) {
                            Text(
                                v?.description ?: "", fontSize = 13.sp,
                                maxLines = if (descExpanded) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                if (descExpanded) "Show less" else "...more", fontSize = 13.sp,
                                fontWeight = FontWeight.Bold, color = accent, modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    }
                }
                item {
                    Text(
                        "COMMENTS  ${s.comments.size}", fontWeight = FontWeight.Bold, color = GlitzPrimary, fontSize = 13.sp, letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(start = 12.dp, top = 16.dp, bottom = 4.dp),
                    )
                }
                items(s.comments, key = { "c" + it.id }) { c ->
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Avatar(c.username, 32)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                listOfNotNull("@" + (c.username ?: "user"), c.createdAt?.take(10)).joinToString(" • "),
                                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                            )
                            Text(c.body, fontSize = 14.sp)
                        }
                    }
                }
                if (s.related.isNotEmpty()) {
                    item {
                        Text(
                            "UP NEXT", fontWeight = FontWeight.Bold, color = GlitzPrimary, fontSize = 13.sp, letterSpacing = 1.5.sp,
                            modifier = Modifier.padding(start = 12.dp, top = 20.dp, bottom = 8.dp),
                        )
                    }
                    items(s.related, key = { "r" + it.shortId }) { r -> VideoCard(r) { onOpen(r.shortId) } }
                }
            }
        }
    }
}

@Composable
private fun Pill(icon: ImageVector, label: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(GlitzSurface2)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 13.sp)
    }
}
