package com.glitz.screen.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One video in this device's watch history.
 * [completed] videos stay in the history but leave the "Continue watching" row.
 */
data class ContinueItem(
    val shortId: String,
    val title: String,
    val thumb: String?,
    val positionMs: Long,
    val durationMs: Long,
    val watchedAt: Long = 0L,
    val completed: Boolean = false,
) {
    val progress: Float
        get() = if (completed) 1f
        else if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}

/** Watch history kept on this device (no login needed). Newest first. */
object WatchProgress {
    private const val PREFS = "glitz_progress"
    private const val KEY = "items"
    private const val MAX_ITEMS = 200

    fun all(ctx: Context): List<ContinueItem> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ContinueItem(
                    shortId = o.getString("id"),
                    title = o.optString("title"),
                    thumb = o.optString("thumb").ifBlank { null },
                    positionMs = o.getLong("pos"),
                    durationMs = o.getLong("dur"),
                    watchedAt = o.optLong("at"),
                    completed = o.optBoolean("done"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Videos that are started, not finished, and past the first few seconds. */
    fun continueWatching(ctx: Context): List<ContinueItem> =
        all(ctx).filter { !it.completed && it.positionMs > 5_000 }

    /** Records the current position and moves the video to the top of the history. */
    fun save(ctx: Context, item: ContinueItem) {
        if (item.positionMs < 3_000) return
        val finished = item.durationMs > 0 && item.positionMs >= item.durationMs * 0.95
        val entry = item.copy(watchedAt = System.currentTimeMillis(), completed = finished)
        write(ctx, listOf(entry) + all(ctx).filter { it.shortId != item.shortId })
    }

    fun markCompleted(ctx: Context, shortId: String) {
        write(ctx, all(ctx).map {
            if (it.shortId == shortId) it.copy(completed = true, positionMs = it.durationMs, watchedAt = System.currentTimeMillis())
            else it
        })
    }

    fun remove(ctx: Context, shortId: String) {
        write(ctx, all(ctx).filter { it.shortId != shortId })
    }

    fun clear(ctx: Context) {
        write(ctx, emptyList())
    }

    private fun write(ctx: Context, items: List<ContinueItem>) {
        val arr = JSONArray()
        items.take(MAX_ITEMS).forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.shortId)
                    .put("title", c.title)
                    .put("thumb", c.thumb ?: "")
                    .put("pos", c.positionMs)
                    .put("dur", c.durationMs)
                    .put("at", c.watchedAt)
                    .put("done", c.completed)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}

/** The viewer's display name on this device. */
object LocalProfile {
    private const val PREFS = "glitz_profile"
    private const val KEY_NAME = "name"

    fun name(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_NAME, null) ?: "Guest"

    fun setName(ctx: Context, name: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_NAME, name).apply()
    }
}
