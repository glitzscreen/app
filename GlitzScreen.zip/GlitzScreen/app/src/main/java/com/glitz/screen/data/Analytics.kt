package com.glitz.screen.data

import android.content.Context
import com.glitz.screen.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Sends the app's viewing to the website, so the website's analytics count it:
 * views, live viewers (presence), and watch history for signed-in accounts.
 * Ad stats are sent by [AdTracker].
 */
object Analytics {
    private const val PREFS = "glitz_analytics"
    private const val KEY_VIEWER = "viewer_id"
    private val JSON_TYPE = "application/json".toMediaType()

    // The session cookie is added too, so views and history count to the signed-in account.
    private val http = OkHttpClient.Builder()
        .callTimeout(10, TimeUnit.SECONDS)
        .addInterceptor(AuthStore.interceptor)
        .build()

    /** A random id for this install. It identifies no person (same idea as the website's visitor id). */
    fun viewerId(ctx: Context): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getString(KEY_VIEWER, null)
            ?: UUID.randomUUID().toString().also { p.edit().putString(KEY_VIEWER, it).apply() }
    }

    /** Returns the response body, or null on any failure (including "not counted" HTTP errors). */
    private fun post(path: String, body: JSONObject): String? = try {
        val req = Request.Builder()
            .url(BuildConfig.BASE_URL + path)
            .post(body.toString().toRequestBody(JSON_TYPE))
            .build()
        http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
    } catch (e: Exception) {
        null
    }

    /**
     * Counts a view once the viewer has watched long enough (the website decides the threshold).
     * Blocking: call it from a background dispatcher. Returns true when the view is counted,
     * or when it was already counted recently.
     */
    fun countView(ctx: Context, shortId: String, watchedSeconds: Int): Boolean {
        val res = post(
            "api/view",
            JSONObject().put("shortId", shortId).put("viewerId", viewerId(ctx)).put("watchedSeconds", watchedSeconds),
        ) ?: return false
        return runCatching {
            val j = JSONObject(res)
            j.optBoolean("counted", false) || j.optString("reason") == "cooldown"
        }.getOrDefault(false)
    }

    /** "Watching now" heartbeat, so the live viewer count includes the app. Blocking. */
    fun heartbeat(ctx: Context, shortId: String) {
        post("api/presence", JSONObject().put("shortId", shortId).put("viewerId", viewerId(ctx)))
    }

    /** Syncs the position to the account (signed-in viewers only), like the website's watch history. */
    fun syncHistory(shortId: String, positionMs: Long, durationMs: Long) {
        if (!AuthStore.signedIn.value) return
        Thread {
            post(
                "api/watch-history/update",
                JSONObject().put("shortId", shortId)
                    .put("positionSeconds", positionMs / 1000)
                    .put("durationSeconds", durationMs / 1000),
            )
        }.start()
    }
}
