package com.glitz.screen.data

import android.content.Context
import com.glitz.screen.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** The update the website describes (set by the admin). */
data class AppUpdateInfo(
    val versionCode: Int = 0,
    val versionName: String = "",
    val minVersionCode: Int = 0,
    val forceUpdate: Boolean = false,
    val apkUrl: String = "",
    val storeUrl: String = "",
    val notes: String = "",
)

/** Checks the website for a newer app build and tells the UI when to show the update screen. */
object AppUpdateChecker {
    private const val PREFS = "glitz_app"
    private const val KEY_SKIPPED = "skipped_version_code"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _pending = MutableStateFlow<AppUpdateInfo?>(null)

    /** Non-null when an update should be offered (forced or optional). */
    val pending: StateFlow<AppUpdateInfo?> = _pending.asStateFlow()

    /** A build is forced if it is below the minimum supported build, or the admin marked the update as forced. */
    fun isForced(info: AppUpdateInfo): Boolean =
        info.forceUpdate || BuildConfig.VERSION_CODE < info.minVersionCode

    /** Called on app start. A failed check never blocks the app. */
    fun refresh() {
        scope.launch {
            val info = runCatching { Api.service.getAppUpdate() }.getOrNull()
            _pending.value =
                if (info != null && info.versionCode > BuildConfig.VERSION_CODE) info
                else if (info != null && BuildConfig.VERSION_CODE < info.minVersionCode) info
                else null
        }
    }

    /** The viewer chose "Later": do not offer this optional version again. */
    fun skip(ctx: Context, info: AppUpdateInfo) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_SKIPPED, info.versionCode).apply()
        _pending.value = null
    }

    fun wasSkipped(ctx: Context, info: AppUpdateInfo): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_SKIPPED, -1) == info.versionCode
}
