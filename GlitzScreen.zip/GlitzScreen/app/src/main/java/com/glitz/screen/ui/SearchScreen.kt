package com.glitz.screen.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.glitz.screen.data.Api

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: SearchViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val s by vm.state.collectAsState()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (s.query.isBlank()) focus.requestFocus() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(end = 12.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            TextField(
                value = s.query, onValueChange = vm::setQuery,
                placeholder = { Text("Search videos") }, singleLine = true,
                shape = RoundedCornerShape(24.dp),
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = GlitzPrimary) },
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = GlitzSurface2, unfocusedContainerColor = GlitzSurface2,
                ),
                trailingIcon = {
                    if (s.query.isNotBlank()) IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Filled.Close, "Clear") }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.searchNow() }),
                modifier = Modifier.weight(1f).focusRequester(focus)
                    .border(1.dp, GlitzBorder, RoundedCornerShape(24.dp)),
            )
        }
        when {
            s.loading -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                CircularProgressIndicator(color = GlitzPrimary)
            }
            s.error != null -> Text(s.error ?: "", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
            s.query.isNotBlank() && s.results.isEmpty() ->
                Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { Text("No results") }
            else -> LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                items(s.results, key = { it.shortId }) { v ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(v.shortId) }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.width(168.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, GlitzBorder, RoundedCornerShape(10.dp)),
                        ) {
                            AsyncImage(
                                model = Api.absolute(v.thumbnailUrl), contentDescription = v.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(GlitzSurface2),
                            )
                            DurationBadge(v.duration ?: "", Modifier.align(Alignment.BottomEnd))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                v.title ?: "", fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(
                                buildString {
                                    append("${compact(v.views)} views")
                                    if (v.locked == true) append(" • 🔒")
                                },
                                color = GlitzMuted, fontSize = 12.sp,
                            )
                        }
                    }
                }
            }
        }
    }
}
