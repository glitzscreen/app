package com.glitz.screen.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.glitz.screen.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// ------------------------------ Home ------------------------------
data class HomeState(
    val loading: Boolean = true,
    val error: String? = null,
    val videos: List<Video> = emptyList(),
    val categories: List<Category> = emptyList(),
    val selectedCategory: String? = null,
    val sort: String = "latest",
)

class HomeViewModel : ViewModel() {
    private val api = Api.service
    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { api.getCategories() }
                .onSuccess { r -> _state.update { it.copy(categories = r.categories) } }
        }
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val s = _state.value
            runCatching { api.getVideos(category = s.selectedCategory, sort = s.sort) }
                .onSuccess { r -> _state.update { it.copy(loading = false, videos = r.videos) } }
                .onFailure { e -> _state.update { it.copy(loading = false, error = e.message ?: "Network error") } }
        }
    }

    init {
        viewModelScope.launch { LiveSync.changes.collect { refreshSilently() } }
    }

    /** The website content changed: reload the feed in place, without the loading spinner. */
    fun refreshSilently() {
        viewModelScope.launch {
            runCatching { api.getCategories() }
                .onSuccess { r -> _state.update { it.copy(categories = r.categories) } }
            val s = _state.value
            runCatching { api.getVideos(category = s.selectedCategory, sort = s.sort) }
                .onSuccess { r -> _state.update { it.copy(videos = r.videos, error = null) } }
        }
    }

    fun setCategory(slug: String?) { _state.update { it.copy(selectedCategory = slug) }; load() }
    fun setSort(sort: String) { _state.update { it.copy(sort = sort) }; load() }
}

// ------------------------------ Search ------------------------------
data class SearchState(
    val query: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val results: List<SearchVideo> = emptyList(),
)

class SearchViewModel : ViewModel() {
    private val api = Api.service
    private val _state = MutableStateFlow(SearchState())
    val state: StateFlow<SearchState> = _state.asStateFlow()
    private var job: Job? = null

    fun setQuery(q: String) {
        _state.update { it.copy(query = q) }
        job?.cancel()
        if (q.isBlank()) { _state.update { it.copy(results = emptyList(), loading = false, error = null) }; return }
        job = viewModelScope.launch { delay(350); run(q) } // debounce
    }

    fun searchNow() {
        val q = _state.value.query
        if (q.isBlank()) return
        job?.cancel()
        job = viewModelScope.launch { run(q) }
    }

    init {
        viewModelScope.launch { LiveSync.changes.collect { refreshSilently() } }
    }

    /** The website content changed: re-run the current search quietly. */
    private suspend fun refreshSilently() {
        val q = _state.value.query.trim()
        if (q.isBlank()) return
        runCatching { api.search(q) }
            .onSuccess { r -> _state.update { it.copy(results = r.videos) } }
    }

    private suspend fun run(q: String) {
        _state.update { it.copy(loading = true, error = null) }
        runCatching { api.search(q.trim()) }
            .onSuccess { r -> _state.update { it.copy(loading = false, results = r.videos) } }
            .onFailure { e -> _state.update { it.copy(loading = false, error = e.message ?: "Search failed") } }
    }
}

// ------------------------------ Watch ------------------------------
data class DetailState(
    val loading: Boolean = true,
    val error: String? = null,
    val video: Video? = null,
    val streamUrl: String? = null,
    val comments: List<Comment> = emptyList(),
    val related: List<Video> = emptyList(),
    val settings: PlayerSettings = PlayerSettings(),
    val qualityOptions: List<QualityOption> = emptyList(),
    val quality: String = "auto",
)

class DetailViewModel(val shortId: String) : ViewModel() {
    private val api = Api.service
    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val settings = runCatching { api.getPlayerSettings().settings }.getOrDefault(PlayerSettings())
                val video = api.getVideo(shortId).video
                val q = if (settings.defaultQuality in listOf("auto", "hd", "sd")) settings.defaultQuality else "auto"
                _state.update { it.copy(video = video, settings = settings, quality = q) }
                val src = api.getDirectSource(shortId, q)
                _state.update { it.copy(streamUrl = src.src, loading = false) }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Failed to load video") }
            }
            runCatching { api.getComments(shortId) }
                .onSuccess { r -> _state.update { it.copy(comments = r.comments) } }
            // Quality menu (only returned when the video really has several qualities)
            runCatching { api.getQualityOptions(shortId) }
                .onSuccess { r -> _state.update { it.copy(qualityOptions = r.options) } }
            // "Up next": more videos from the same category
            val cat = _state.value.video?.categorySlug
            runCatching { api.getVideos(category = cat, sort = "views") }
                .onSuccess { r ->
                    _state.update { it.copy(related = r.videos.filter { v -> v.shortId != shortId }.take(20)) }
                }
        }
    }

    init {
        viewModelScope.launch { LiveSync.changes.collect { refreshMeta() } }
    }

    /**
     * Title, description, comments and "Up next" can change while a video is open.
     * The stream is NOT reloaded here, so playback is never interrupted.
     */
    fun refreshMeta() {
        viewModelScope.launch {
            runCatching { api.getVideo(shortId).video }
                .onSuccess { video -> _state.update { it.copy(video = video) } }
            runCatching { api.getComments(shortId) }
                .onSuccess { r -> _state.update { it.copy(comments = r.comments) } }
            runCatching { api.getVideos(category = _state.value.video?.categorySlug, sort = "views") }
                .onSuccess { r ->
                    _state.update { it.copy(related = r.videos.filter { v -> v.shortId != shortId }.take(20)) }
                }
        }
    }

    /** Call when the player reports an error: the CDN link may have expired. */
    fun refreshStream() {
        viewModelScope.launch {
            runCatching { api.getDirectSource(shortId, _state.value.quality, refresh = 1) }
                .onSuccess { src -> _state.update { it.copy(streamUrl = src.src) } }
        }
    }

    /** Switch quality; the player reloads the new URL at the same position. */
    fun setQuality(id: String) {
        viewModelScope.launch {
            runCatching { api.getDirectSource(shortId, id) }
                .onSuccess { src -> _state.update { it.copy(streamUrl = src.src, quality = id) } }
        }
    }
}
