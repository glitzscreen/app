package com.glitz.screen.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Same palette as the website's default theme (--bg, --surface-2, --primary ...)
val GlitzBg = Color(0xFF05070F)
val GlitzSurface = Color(0xFF0B1020)
val GlitzSurface2 = Color(0xFF101830)
val GlitzElevated = Color(0xFF16213F)
val GlitzPrimary = Color(0xFF00E5FF)
val GlitzInk = Color(0xFF00141A)
val GlitzSecondary = Color(0xFFB46BFF)
val GlitzText = Color(0xFFE6F1FF)
val GlitzMuted = Color(0xFF7F93B5)
val GlitzBorder = Color(0xFF1B2A4A)

/** Cyan -> violet gradient used by the logo mark, avatars and gradient buttons on the website. */
val GlitzBrand = Brush.linearGradient(listOf(GlitzPrimary, GlitzSecondary))

/** Card surface gradient from the website's .card style. */
val GlitzCardBrush = Brush.verticalGradient(listOf(Color(0xFF141E3A), Color(0xFF0B1020)))

@Composable
fun GlitzTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GlitzPrimary,
            onPrimary = GlitzInk,
            secondary = GlitzSecondary,
            background = GlitzBg,
            surface = GlitzBg,
            surfaceVariant = GlitzSurface2,
            onBackground = GlitzText,
            onSurface = GlitzText,
            onSurfaceVariant = GlitzMuted,
        ),
        content = content,
    )
}
