package com.glitz.screen.data

import android.content.Context
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.Interceptor

data class MeResponse(val user: MeUser? = null)

/** The signed-in website account (fields as the website returns them). */
data class MeUser(
    val id: Int? = null,
    val username: String? = null,
    @SerializedName("lang_pref") val langPref: String? = null,
    val country: String? = null,
    @SerializedName("username_confirmed") val usernameConfirmed: Int? = null,
)

data class LangModeBody(val mode: String)
data class LangModeResponse(val ok: Boolean = false, val mode: String? = null)

/**
 * Google sign-in session for the website account.
 * The website signs the viewer in with Google in the browser and hands the session
 * back through the app's App Link; this store keeps it and sends it with every request.
 */
object AuthStore {
    private const val PREFS = "glitz_auth"
    private const val KEY = "session"
    private const val COOKIE = "sid" // the website's session cookie name

    private var appCtx: Context? = null
    @Volatile private var token: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _user = MutableStateFlow<MeUser?>(null)
    val user: StateFlow<MeUser?> = _user.asStateFlow()
    private val _signedIn = MutableStateFlow(false)
    val signedIn: StateFlow<Boolean> = _signedIn.asStateFlow()

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        token = prefs(ctx).getString(KEY, null)
        _signedIn.value = token != null
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Keeps the session the website handed over after Google sign-in. */
    fun save(newToken: String) {
        appCtx?.let { prefs(it).edit().putString(KEY, newToken).apply() }
        token = newToken
        _signedIn.value = true
        refresh()
        LiveSync.forceRefresh()
    }

    fun signOut() {
        // Show signed-out at once, but keep the session until the website has been told to end it
        // (the logout request needs the session cookie).
        _user.value = null
        _signedIn.value = false
        scope.launch {
            runCatching { Api.service.logout() } // a network error is fine; the session expires on its own
            token = null
            appCtx?.let { prefs(it).edit().remove(KEY).apply() }
            LiveSync.forceRefresh()
        }
    }

    /** Loads the account from the website. A session the website no longer accepts is cleared. */
    fun refresh() {
        if (token == null) {
            _user.value = null
            return
        }
        scope.launch {
            val res = runCatching { Api.service.getMe() }.getOrNull() ?: return@launch // offline: keep what we have
            if (res.user == null) signOut() else _user.value = res.user
        }
    }

    /** Saves the language on the account; the website then shows that language's videos. */
    suspend fun setLanguage(mode: String): Boolean {
        val ok = runCatching { Api.service.setLangMode(LangModeBody(mode)).ok }.getOrDefault(false)
        if (ok) {
            _user.value = _user.value?.copy(langPref = mode)
            LiveSync.forceRefresh()
        }
        return ok
    }

    /**
     * Added to every request to the website: the client header (so the website's analytics
     * count the app separately from the web) and the session cookie (so it knows who is asking).
     */
    val interceptor = Interceptor { chain ->
        val t = token
        val builder = chain.request().newBuilder().header("X-Glitz-Client", "android")
        if (t != null) builder.header("Cookie", "$COOKIE=$t")
        chain.proceed(builder.build())
    }
}
