package com.glitz.screen.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Website-style preloader: spinning neon reel, pulsing name and a light sweep,
 * then a fade-out. Mirrors the website's #fbfPre splash.
 */
object SplashGate {
    private var shownThisSession = false

    /** First launch of the app session shows the splash a little longer (0.9 s), later launches 0.25 s. */
    fun nextDurationMs(): Long {
        val d = if (shownThisSession) 250L else 900L
        shownThisSession = true
        return d
    }
}

@Composable
fun GlitzSplash(durationMs: Long, onFinished: () -> Unit) {
    val fade = remember { Animatable(1f) }
    val t = rememberInfiniteTransition(label = "splash")
    val pulse by t.animateFloat(
        initialValue = 1f, targetValue = 0.55f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse",
    )
    val sweep by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "sweep",
    )

    LaunchedEffect(Unit) {
        delay(durationMs)
        fade.animateTo(0f, tween(450))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(Brush.radialGradient(listOf(GlitzSurface2, GlitzBg), radius = 1200f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            GlitzReel(dim = 84.dp, spinMs = 1600, orbitMs = 5000)
            Spacer(Modifier.height(14.dp))
            Text(
                "GLITZ SCREEN",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 4.8.sp,
                color = GlitzText,
                style = TextStyle(shadow = Shadow(color = GlitzPrimary, offset = Offset.Zero, blurRadius = 14f)),
                modifier = Modifier.graphicsLayer { alpha = pulse },
            )
            Spacer(Modifier.height(14.dp))
            // progress line with a light sweep
            Canvas(Modifier.width(140.dp).height(2.dp)) {
                drawRoundRect(GlitzBorder, cornerRadius = CornerRadius(size.height / 2f))
                val w = size.width * 0.4f
                val x = -w + sweep * (size.width + w)
                val left = maxOf(0f, x)
                val right = minOf(size.width, x + w)
                if (right > left) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color.Transparent, GlitzPrimary, GlitzSecondary, Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + w, 0f),
                        ),
                        topLeft = Offset(left, 0f),
                        size = Size(right - left, size.height),
                    )
                }
            }
        }
    }
}
